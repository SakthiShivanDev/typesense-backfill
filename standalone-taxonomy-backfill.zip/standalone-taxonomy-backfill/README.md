# Standalone Competitor-Taxonomy Backfill

Maps every medicine in our catalog to the department / category / subcategory that competitor pharmacy sites file it under. A medicine that no site lists is marked **NOT IDENTIFIED**.

Self-contained — no dependency on the main `medivoy-pharmacy.api` repo, no Prisma. Just `pg`, `exceljs` and Node's built-in `fetch`. **Read-only** against Postgres.

## How it works (two steps)

1. **Crawl** a site's category tree once → a local index (`index/<site>.jsonl`): every drug the site lists, with where it files it. For 1mg this is ~300 classes, a few thousand requests in total.
2. **Map** our ~744k medicines against that index locally (name matching, no network). Fast, and repeatable without hitting the site again.

Per-medicine live searching still exists (`LIVE_FALLBACK=true`, or automatically when a site has no index) but it is slow and gets rate-limited, so it is only a fallback.

## How each medicine gets mapped (1mg)

1. **Name match** — our brand name matches a drug 1mg lists → that drug's exact department + category. `Match Type = name`.
2. **Composition match** — 1mg doesn't list the brand, but lists other drugs with the same molecules (strengths ignored, order ignored) → the class most of them are filed under. `Match Type = composition`; the score is the share of those drugs in that class. Only used when the share is ≥ `MIN_COMPOSITION_CONFIDENCE` (default 0.6).
3. Neither → **NOT IDENTIFIED**.

Non-drug products (supplements, devices, personal care, homeopathy) have no drug composition on 1mg, so they end up NOT IDENTIFIED for 1mg.

## Setup

```bash
npm install
cp .env.example .env   # set DATABASE_URL
```

From this repo checkout you can reuse the parent API `.env`: `node --env-file=../.env backfill-competitor-taxonomy.mjs`

## Run

```bash
# 1. Crawl each site once into ./index (both resumable; run them in parallel if you like)
node crawl-1mg.mjs        # Tata 1mg therapeutic-class tree, ~1 hour.   Smoke test: CRAWL_CLASS_LIMIT=3
node crawl-netmeds.mjs    # Netmeds full catalog (~179k products, ~1,500 requests, ~15-30 min).   Smoke test: CRAWL_PAGE_LIMIT=3
node crawl-apollo.mjs     # Apollo: ~267 category pages + one query per salt. Run AFTER the two above (it reuses their salt names). Smoke test: CRAWL_QUERY_LIMIT=20

# 2. Map the catalog. Start with a sample and check the Excel:
SAMPLE=2000 node --env-file=../.env backfill-competitor-taxonomy.mjs

# 3. Full catalog (resumable — finished medicines are skipped)
node --env-file=../.env backfill-competitor-taxonomy.mjs

# Rebuild JSON/Excel from results collected so far, without querying anything
EXPORT_ONLY=true node --env-file=../.env backfill-competitor-taxonomy.mjs
```

PowerShell: `$env:SAMPLE='2000'; node --env-file=..\.env backfill-competitor-taxonomy.mjs; Remove-Item Env:SAMPLE`

Options (env vars): `MIN_COMPOSITION_CONFIDENCE`, `MIN_COMPOSITION_SUPPORT`, `SAMPLE`, `BACKFILL_LIMIT`, `SITES`, `CONCURRENCY`, `RPS_<SITE>`, `OUT_DIR`, `INDEX_DIR`, `LIVE_FALLBACK`, `FRESH`, `EXPORT_ONLY` — see `.env.example`.

## Output — `output/competitor-taxonomy/`

| File | What |
|---|---|
| `results.jsonl` | Working file, one line per medicine. This is the resume state. |
| `taxonomy.json` | Final JSON array, one object per medicine with each site's result. |
| `taxonomy.xlsx` | Final Excel: one row per medicine, a column group per site, plus a Summary sheet. |

Per site the sheet has: status, matched name, department, category, subcategory, full path, URL. **Primary Source** columns take the first site (1mg, then PharmEasy…) that found the medicine.

`Result` column: `identified` (at least one site lists it), `NOT IDENTIFIED` (every site checked said no), `incomplete` (a site errored and nothing else found it — re-run to retry; an error is never recorded as "not identified").

## Sites

| Site | Status | Taxonomy depth |
|---|---|---|
| Tata 1mg | working — crawl-and-map (`crawl-1mg.mjs`) | 2 levels: department = therapeutic parent class, category = class |
| Netmeds | working — crawl-and-map (`crawl-netmeds.mjs`, public JSON search API) | 4 levels: Medicine/Wellness → L1 → L2 → L3. Department = vertical, category = L1, subcategory = L2; L3 is in the Full Path column |
| PharmEasy | working via live search only | shallow (breadcrumb is just "Medicines") |
| Apollo | working — crawl-and-map (`crawl-apollo.mjs`, public GraphQL `getAplCategoryProducts` with an anonymous token). Category pages cover OTC/wellness/baby/devices; Rx medicines are reached through one query per salt | 3 levels: `classifier_1 › classifier_2 › classifier_3` (e.g. C.N.S DRUGS › ANALGESICS & ANTIPYRETICS). Products with no class on Apollo are left out |
| Truemeds | not usable — product-page breadcrumb is only "Home › product", no category | — |
| MedPlus | registered, **unsupported** — Akamai returns 403 to non-browser clients | — |

Adding a site = a `crawl-<site>.mjs` that writes `index/<site>.jsonl` (rows `{ name, slug, manufacturer, composition, path: [level1, level2, ...] }`) plus an adapter in `lib/adapters.mjs`.

## Matching

Names are compared token-by-token after dropping pack/form words (tablet, strip, ml…). The first token (the brand) must be identical and overall similarity must be ≥ 0.7, so `Crocin 500` will not match a different brand with the same strength. Review `matchedName` and `score` in the output when checking quality.

**Coverage note:** 1mg's therapeutic classes cover drugs only. Non-drug products (supplements, personal care, devices) are filed elsewhere on 1mg and will show as NOT IDENTIFIED for 1mg until a crawler for those sections is added.
