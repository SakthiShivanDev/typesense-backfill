// Crawls Netmeds' whole product catalog ONCE (~179k products, ~120 per request)
// and saves each product with the category path Netmeds files it under.
// backfill-competitor-taxonomy.mjs then maps our medicines against this index.
//
// Netmeds' storefront loads products from a public JSON endpoint
//   /ext/search/application/api/v1.0/products?page_id=<cursor>&page_size=N
// Each item carries: verticalspecification (Medicine / Wellness / ...),
// categorynamelevel1/2/3, genericnamewithdosage (composition), manufacturername.
//
// Output (INDEX_DIR, default ./index):
//   netmeds.jsonl           one line per product: { name, slug, manufacturer, composition, path: [vertical, l1, l2, l3] }
//   netmeds-progress.json   resume cursor
//
// Usage:
//   node crawl-netmeds.mjs
//   CRAWL_PAGE_LIMIT=3 node crawl-netmeds.mjs     # smoke test
//   RPS_NETMEDS=2 node crawl-netmeds.mjs

import { appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { RateLimiter, httpGet } from './lib/core.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const INDEX_DIR = process.env.INDEX_DIR || join(__dirname, 'index');
const PAGE_LIMIT = Number.parseInt(process.env.CRAWL_PAGE_LIMIT ?? '', 10) || Infinity;
const PAGE_SIZE = 120; // server-side cap; asking for more still returns 120

const limiter = new RateLimiter('netmeds-crawl', Number(process.env.RPS_NETMEDS ?? 2));
const DRUGS_FILE = join(INDEX_DIR, 'netmeds.jsonl');
const PROGRESS_FILE = join(INDEX_DIR, 'netmeds-progress.json');

mkdirSync(INDEX_DIR, { recursive: true });

const progress = existsSync(PROGRESS_FILE) ? JSON.parse(readFileSync(PROGRESS_FILE, 'utf8')) : { cursor: '*', pages: 0, items: 0 };
const clean = (v) => (typeof v === 'string' ? v.trim() : '');

function toRow(item) {
  const a = item.attributes ?? {};
  const path = [a.verticalspecification, a.categorynamelevel1, a.categorynamelevel2, a.categorynamelevel3]
    .map(clean)
    .filter(Boolean);
  return {
    name: item.name,
    slug: item.slug,
    manufacturer: clean(a.manufacturername),
    composition: clean(a.genericnamewithdosage) || clean(a.genericname),
    rx: clean(a['mstar-rxrequired']),
    path
  };
}

async function main() {
  console.log(`Netmeds crawl: resuming at cursor "${progress.cursor}" (${progress.pages} pages / ${progress.items} items done)`);
  const started = Date.now();
  let pagesThisRun = 0;

  for (;;) {
    if (pagesThisRun >= PAGE_LIMIT) break;
    const url =
      'https://www.netmeds.com/ext/search/application/api/v1.0/products' +
      `?page_id=${encodeURIComponent(progress.cursor)}&page_size=${PAGE_SIZE}`;
    const { status, text } = await httpGet(url, limiter, { maxBytes: 10_000_000, timeoutMs: 45_000 });
    if (status >= 400) throw new Error(`HTTP ${status} at cursor ${progress.cursor}`);

    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error(`unparseable response at cursor ${progress.cursor}`);
    }
    const items = data.items ?? [];
    if (items.length) {
      appendFileSync(DRUGS_FILE, items.map((i) => JSON.stringify(toRow(i))).join('\n') + '\n');
    }

    progress.pages++;
    progress.items += items.length;
    pagesThisRun++;
    const next = data.page?.next_id;
    const done = !data.page?.has_next || !items.length || next === undefined;
    progress.cursor = done ? progress.cursor : String(next);
    progress.total = data.page?.item_total;
    progress.finished = done;
    writeFileSync(PROGRESS_FILE, JSON.stringify(progress));

    process.stdout.write(
      `\r  pages ${progress.pages} | items ${progress.items}/${progress.total ?? '?'} | ` +
        `${((Date.now() - started) / 60000).toFixed(1)} min   `
    );
    if (done) break;
  }
  console.log(`\nDone for now: ${progress.items} products in ${DRUGS_FILE}${progress.finished ? ' (complete)' : ' (re-run to continue)'}`);
}

main().catch((error) => {
  console.error('\n' + error.message);
  process.exit(1);
});
