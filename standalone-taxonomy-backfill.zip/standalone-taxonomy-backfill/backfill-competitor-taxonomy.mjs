// For every medicine in the catalog, look it up on competitor pharmacy sites
// (Tata 1mg, PharmEasy, ...) and record how each site files it: department /
// category / subcategory. Medicines no site lists are marked NOT IDENTIFIED.
//
// Self-contained — no Prisma, no dependency on the main repo, just `pg`,
// `exceljs` and built-in fetch. READ-ONLY against the database.
//
// Output (OUT_DIR, default ./output/competitor-taxonomy):
//   results.jsonl   working file, appended per medicine — makes runs resumable
//   taxonomy.json   final JSON array
//   taxonomy.xlsx   final Excel: one row per medicine, a column group per site
//
// Usage:
//   DATABASE_URL=... SAMPLE=200 node backfill-competitor-taxonomy.mjs   # try this first
//   DATABASE_URL=... node backfill-competitor-taxonomy.mjs              # full catalog, resumes automatically
//   EXPORT_ONLY=true node backfill-competitor-taxonomy.mjs              # just rebuild JSON + Excel

import { createReadStream, createWriteStream, existsSync, mkdirSync, rmSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline';
import { once } from 'node:events';
import pg from 'pg';
import ExcelJS from 'exceljs';
import { ADAPTERS } from './lib/adapters.mjs';
import { RateLimiter } from './lib/core.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));

// See backfill-medicines.mjs in ../standalone-backfill for why the SSL config
// is built by hand instead of passing the connection string straight to pg.
function parseConnectionConfig(databaseUrl) {
  const url = new URL(databaseUrl);
  return {
    host: url.hostname,
    port: Number(url.port),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: url.pathname.replace(/^\//, ''),
    ssl: { rejectUnauthorized: false }
  };
}

function positiveInt(value, fallback) {
  const parsed = Number.parseInt(value ?? '', 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}
const truthy = (value) => ['1', 'true', 'yes'].includes((value ?? '').toLowerCase());
const quoteIdentifier = (value) => `"${value.replace(/"/g, '""')}"`;

const DATABASE_URL = process.env.DATABASE_URL;
const EXPORT_ONLY = truthy(process.env.EXPORT_ONLY);
if (!DATABASE_URL && !EXPORT_ONLY) {
  console.error('Missing required env var: DATABASE_URL');
  process.exit(1);
}

const DB_SCHEMA =
  process.env.DATABASE_SCHEMA || (DATABASE_URL && new URL(DATABASE_URL).searchParams.get('schema')) || 'public';
const T = (name) => `${quoteIdentifier(DB_SCHEMA)}.${quoteIdentifier(name)}`;

const SAMPLE = positiveInt(process.env.SAMPLE, null);
const BACKFILL_LIMIT = positiveInt(process.env.BACKFILL_LIMIT, null);
const BATCH_SIZE = positiveInt(process.env.BATCH_SIZE, 2000);
const CONCURRENCY = positiveInt(process.env.CONCURRENCY, 8);
const FRESH = truthy(process.env.FRESH);
const wantedSites = process.env.SITES?.split(',').map((s) => s.trim()).filter(Boolean);
const OUT_DIR =
  process.env.OUT_DIR || join(__dirname, 'output', SAMPLE ? `competitor-taxonomy-sample-${SAMPLE}` : 'competitor-taxonomy');
const RESULTS = join(OUT_DIR, 'results.jsonl');

// Working sites by default; unsupported ones only when named explicitly in SITES.
const adapters = ADAPTERS.filter((a) => (wantedSites ? wantedSites.includes(a.id) : a.supported !== false));
if (!adapters.length) {
  console.error(`No matching sites. Available: ${ADAPTERS.map((a) => a.id).join(', ')}`);
  process.exit(1);
}

/* ───────────── helpers ───────────── */

const isFinal = (r) => r?.status === 'found' || r?.status === 'not_found';

function computeOverall(sites) {
  const results = adapters.filter((a) => sites[a.id]?.status !== 'unsupported').map((a) => sites[a.id]);
  if (results.some((r) => r?.status === 'found')) return 'identified';
  // "Not identified" only when every active site gave a definite no; an error is never a no.
  if (results.length && results.every((r) => r?.status === 'not_found')) return 'not_identified';
  return 'incomplete';
}

/** Latest record per medicine id (results.jsonl is append-only, later lines win). */
async function loadExisting() {
  const map = new Map();
  if (!existsSync(RESULTS)) return map;
  const rl = createInterface({ input: createReadStream(RESULTS, 'utf8'), crlfDelay: Infinity });
  for await (const line of rl) {
    if (!line.trim()) continue;
    try {
      const rec = JSON.parse(line);
      map.set(rec.id, rec);
    } catch {
      // torn last line from a killed run — that medicine is simply redone
    }
  }
  return map;
}

const SELECT_COLUMNS = `
  m."id", m."brandName", m."genericName", m."manufacturer", m."packForm", m."packSize",
  d."name" AS "ourDepartment", c."name" AS "ourCategory", s."name" AS "ourSubcategory"`;
const FROM_JOINS = `
  FROM ${T('Medicine')} m
  LEFT JOIN ${T('Department')} d ON d."id" = m."departmentId"
  LEFT JOIN ${T('Category')} c ON c."id" = m."categoryId"
  LEFT JOIN ${T('Subcategory')} s ON s."id" = m."subcategoryId"`;

async function* catalogBatches(client) {
  if (SAMPLE) {
    const { rows } = await client.query(`SELECT ${SELECT_COLUMNS} ${FROM_JOINS} ORDER BY random() LIMIT $1`, [SAMPLE]);
    yield rows;
    return;
  }
  // Keyset pagination on id: stable order, no OFFSET cost across ~744k rows.
  let cursor = null;
  for (;;) {
    const { rows } = await client.query(
      `SELECT ${SELECT_COLUMNS} ${FROM_JOINS} WHERE ($1::text IS NULL OR m."id" > $1) ORDER BY m."id" ASC LIMIT $2`,
      [cursor, BATCH_SIZE]
    );
    if (!rows.length) return;
    cursor = rows[rows.length - 1].id;
    yield rows;
  }
}

/* ───────────── lookup loop ───────────── */

async function run() {
  mkdirSync(OUT_DIR, { recursive: true });
  if (FRESH && existsSync(RESULTS)) rmSync(RESULTS);

  const existing = await loadExisting();
  const limiters = new Map(
    adapters.map((a) => [a.id, new RateLimiter(a.id, Number(process.env[`RPS_${a.id.toUpperCase()}`] ?? a.defaultRps))])
  );
  const client = new pg.Client(parseConnectionConfig(DATABASE_URL));
  await client.connect();

  const out = createWriteStream(RESULTS, { flags: 'a' });
  out.setMaxListeners(0); // many workers may wait on 'drain' at once
  const stats = { processed: 0, skipped: 0, identified: 0, not_identified: 0, incomplete: 0 };
  const started = Date.now();
  let seen = 0;

  const processOne = async (med) => {
    const prior = existing.get(med.id);
    const sites = { ...(prior?.sites ?? {}) };

    // Only redo sites with no definite answer yet (errors and newly added sites get retried).
    // ("unsupported" is permanent only for sites we cannot query at all; a site awaiting its crawl is retried.)
    const todo = adapters.filter(
      (a) => !isFinal(sites[a.id]) && !(a.supported === false && sites[a.id]?.status === 'unsupported')
    );
    if (!todo.length && prior) {
      stats.skipped++;
      return;
    }

    await Promise.all(
      todo.map(async (adapter) => {
        try {
          sites[adapter.id] = await adapter.lookup(med, limiters.get(adapter.id));
        } catch (error) {
          sites[adapter.id] = { status: 'error', error: error instanceof Error ? error.message : String(error) };
        }
      })
    );

    const overall = computeOverall(sites);
    const primary = adapters.find((a) => sites[a.id]?.status === 'found' && sites[a.id].department);
    const record = {
      ...med,
      sites,
      overall,
      primary: primary
        ? {
            site: primary.id,
            matchType: sites[primary.id].matchType,
            department: sites[primary.id].department,
            category: sites[primary.id].category,
            subcategory: sites[primary.id].subcategory
          }
        : undefined,
      checkedAt: new Date().toISOString()
    };
    if (!out.write(JSON.stringify(record) + '\n')) await once(out, 'drain');
    existing.set(med.id, record);
    stats.processed++;
    stats[overall]++;
  };

  const progress = () => {
    const rate = stats.processed / Math.max(1, (Date.now() - started) / 1000);
    process.stdout.write(
      `\r  processed ${stats.processed} (skipped ${stats.skipped}) | identified ${stats.identified} ` +
        `not_identified ${stats.not_identified} incomplete ${stats.incomplete} | ${rate.toFixed(2)}/s   `
    );
  };
  const ticker = setInterval(progress, 5000);

  // Bounded worker pool over the streamed catalog.
  const inFlight = new Set();
  outer: for await (const batch of catalogBatches(client)) {
    for (const med of batch) {
      if (BACKFILL_LIMIT && seen >= BACKFILL_LIMIT) break outer;
      seen++;
      const task = processOne(med)
        .catch((e) => console.error(`\n  ${med.id} failed: ${e}`))
        .finally(() => inFlight.delete(task));
      inFlight.add(task);
      if (inFlight.size >= CONCURRENCY) await Promise.race(inFlight);
    }
  }
  await Promise.all(inFlight);
  clearInterval(ticker);
  progress();
  process.stdout.write('\n');
  out.end();
  await once(out, 'finish');
  await client.end();
}

/* ───────────── export: JSON + Excel ───────────── */

async function exportOutputs() {
  const records = await loadExisting();
  const jsonPath = join(OUT_DIR, 'taxonomy.json');
  const xlsxPath = join(OUT_DIR, 'taxonomy.xlsx');
  // Skip site column groups that never produced a real answer (unsupported sites).
  const siteIds = adapters
    .filter((a) => [...records.values()].some((r) => r.sites?.[a.id] && r.sites[a.id].status !== 'unsupported'))
    .map((a) => a.id);

  // JSON — streamed array so 744k records never sit in one string.
  const json = createWriteStream(jsonPath);
  json.write('[\n');
  let first = true;
  for (const rec of records.values()) {
    if (!json.write((first ? '' : ',\n') + JSON.stringify(rec))) await once(json, 'drain');
    first = false;
  }
  json.write('\n]\n');
  json.end();
  await once(json, 'finish');

  // Excel — streaming writer, one row per medicine.
  const wb = new ExcelJS.stream.xlsx.WorkbookWriter({ filename: xlsxPath, useStyles: true });
  const ws = wb.addWorksheet('Taxonomy', { views: [{ state: 'frozen', ySplit: 1, xSplit: 2 }] });
  const columns = [
    { key: 'id', header: 'Medicine ID', width: 38 },
    { key: 'brandName', header: 'Brand Name', width: 36 },
    { key: 'genericName', header: 'Generic Name', width: 36 },
    { key: 'manufacturer', header: 'Manufacturer', width: 28 },
    { key: 'pack', header: 'Pack', width: 24 },
    { key: 'ourDept', header: 'Our Department', width: 22 },
    { key: 'ourCat', header: 'Our Category', width: 22 },
    { key: 'ourSub', header: 'Our Subcategory', width: 22 },
    { key: 'overall', header: 'Result', width: 16 },
    { key: 'primarySite', header: 'Primary Source', width: 14 },
    { key: 'primaryType', header: 'Match Type (name / composition)', width: 18 },
    { key: 'primaryDept', header: 'Primary Department', width: 24 },
    { key: 'primaryCat', header: 'Primary Category', width: 24 },
    { key: 'primarySub', header: 'Primary Subcategory', width: 24 }
  ];
  for (const id of siteIds) {
    const label = adapters.find((a) => a.id === id).label;
    columns.push(
      { key: `${id}_status`, header: `${label} — Status`, width: 13 },
      { key: `${id}_type`, header: `${label} — Match Type`, width: 14 },
      { key: `${id}_name`, header: `${label} — Matched Name`, width: 34 },
      { key: `${id}_dept`, header: `${label} — Department`, width: 24 },
      { key: `${id}_cat`, header: `${label} — Category`, width: 24 },
      { key: `${id}_sub`, header: `${label} — Subcategory`, width: 24 },
      { key: `${id}_path`, header: `${label} — Full Path`, width: 44 },
      { key: `${id}_url`, header: `${label} — URL`, width: 44 }
    );
  }
  ws.columns = columns;
  const headerRow = ws.getRow(1);
  headerRow.height = 32;
  headerRow.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1A4B8C' } };
    cell.alignment = { vertical: 'middle', wrapText: true };
  });
  headerRow.commit();

  const counts = { identified: 0, not_identified: 0, incomplete: 0 };
  const perSite = {};

  for (const rec of records.values()) {
    counts[rec.overall]++;
    const row = {
      id: rec.id,
      brandName: rec.brandName,
      genericName: rec.genericName,
      manufacturer: rec.manufacturer,
      pack: [rec.packForm, rec.packSize].filter(Boolean).join(' · '),
      ourDept: rec.ourDepartment ?? '',
      ourCat: rec.ourCategory ?? '',
      ourSub: rec.ourSubcategory ?? '',
      overall: rec.overall === 'not_identified' ? 'NOT IDENTIFIED' : rec.overall,
      primarySite: rec.primary?.site ?? '',
      primaryType: rec.primary?.matchType ?? '',
      primaryDept: rec.primary?.department ?? '',
      primaryCat: rec.primary?.category ?? '',
      primarySub: rec.primary?.subcategory ?? ''
    };
    for (const id of siteIds) {
      const s = rec.sites?.[id];
      const stat = s?.status ?? 'missing';
      perSite[id] ??= {};
      perSite[id][stat] = (perSite[id][stat] ?? 0) + 1;
      row[`${id}_status`] = s?.status ?? '';
      row[`${id}_type`] = s?.matchType ?? '';
      row[`${id}_name`] = s?.matchedName ?? '';
      row[`${id}_dept`] = s?.department ?? '';
      row[`${id}_cat`] = s?.category ?? '';
      row[`${id}_sub`] = s?.subcategory ?? '';
      row[`${id}_path`] = s?.path?.join(' > ') ?? '';
      row[`${id}_url`] = s?.url ?? '';
    }
    const added = ws.addRow(row);
    if (rec.overall === 'not_identified') {
      added.getCell('overall').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFCDD2' } };
    }
    added.commit();
  }
  ws.autoFilter = { from: 'A1', to: { row: 1, column: columns.length } };
  ws.commit();

  const summary = wb.addWorksheet('Summary');
  summary.columns = [{ width: 36 }, { width: 16 }, { width: 16 }, { width: 16 }, { width: 16 }];
  summary.addRow(['Overall result', 'Medicines']).commit();
  for (const [k, v] of Object.entries(counts)) summary.addRow([k, v]).commit();
  summary.addRow([]).commit();
  summary.addRow(['Per site', 'found', 'not_found', 'error', 'missing']).commit();
  for (const [id, by] of Object.entries(perSite)) {
    summary.addRow([id, by.found ?? 0, by.not_found ?? 0, by.error ?? 0, by.missing ?? 0]).commit();
  }
  summary.commit();
  await wb.commit();

  console.log(`\nExported ${records.size} medicines`);
  console.log(`  JSON : ${jsonPath}`);
  console.log(`  Excel: ${xlsxPath}`);
  console.log(
    `  identified ${counts.identified} | not identified ${counts.not_identified} | incomplete ${counts.incomplete}`
  );
}

/* ───────────── entry ───────────── */

async function main() {
  mkdirSync(OUT_DIR, { recursive: true });
  if (!EXPORT_ONLY) {
    console.log(
      `Sites: ${adapters.map((a) => a.id).join(', ')} | concurrency ${CONCURRENCY}` +
        (SAMPLE ? ` | random sample of ${SAMPLE}` : BACKFILL_LIMIT ? ` | limit ${BACKFILL_LIMIT}` : ' | full catalog')
    );
    await run();
  }
  await exportOutputs();
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
