// Self-contained symptom-embedding backfill. No dependency on the
// medivoy-pharmacy.api repo or Prisma — just `pg` and built-in fetch.
// Mirrors the exact logic of backfillSymptomEmbeddingsForCategory() in
// src/services/search-index.service.ts.
//
// This is SLOW and CPU/RAM-heavy on the Typesense server — each document
// needs real ML inference (ts/e5-small), not just indexing. Measured
// ~3.9 docs/sec in testing (25x slower than plain-text indexing). See
// docs/deployment/typesense-search-rollout.md in the main repo for the
// full category list, sizes, and time estimates.
//
// Usage:
//   CATEGORY=pain-and-fever node backfill-symptom-embeddings.mjs   # one category
//   CATEGORY=all node backfill-symptom-embeddings.mjs              # every category, smallest first
//
// "CATEGORY=all" runs every category in one process, ordered by how many
// medicines are in each (smallest/fastest first) — so quick categories
// finish and give you feedback early, and the largest one (pain-and-fever,
// ~72k medicines, ~5hrs) runs last rather than blocking everything behind it.
// Safe to Ctrl+C between categories and resume later — already-embedded
// categories are skipped is NOT automatic, re-running re-embeds them (upsert
// is idempotent, just re-does the work) unless you pass a specific CATEGORY.

import pg from 'pg';

// pg's connection-string SSL parsing takes precedence over an explicit
// `ssl` option when the string itself contains sslmode=require, so passing
// both leaves the strict-verification behavior in place (confirmed: still
// got "self-signed certificate in certificate chain" with rejectUnauthorized:
// false set alongside an sslmode=require URL). Parsing to a plain config
// object and dropping sslmode from it entirely is what actually works.
function parseConnectionConfig(databaseUrl) {
  const url = new URL(databaseUrl);
  return {
    host: url.hostname,
    port: Number(url.port),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: url.pathname.replace(/^\//, ''),
    ssl: { rejectUnauthorized: false }
  };
}

const DATABASE_URL = process.env.DATABASE_URL;
const TYPESENSE_HOST = process.env.TYPESENSE_HOST;
const TYPESENSE_PORT = process.env.TYPESENSE_PORT || '443';
const TYPESENSE_PROTOCOL = process.env.TYPESENSE_PROTOCOL || 'https';
const TYPESENSE_API_KEY = process.env.TYPESENSE_API_KEY;
const CATEGORY_ARG = process.env.CATEGORY;
const BATCH_SIZE = 50; // small on purpose — each doc needs real ML inference, not just I/O; a 200-doc batch took ~46s and hit a 10s client timeout in earlier testing

// Must match SYMPTOM_EMBEDDING_CATEGORIES in src/services/search-index.service.ts exactly.
// Rebuilt from a full scan of all 982 distinct category values (the original
// 30 came from only the top 60 by count, which silently dropped real symptom
// categories like "headache-and-fever", 487 medicines). Now 119 categories,
// covering 423,903 medicines.
const SYMPTOM_EMBEDDING_CATEGORIES = new Set([
  'bacterial-infections', 'pain-and-fever', 'acidity-and-heartburn', 'diabetes-medicines',
  'cough-and-cold', 'anxiety-sleep-and-mood', 'blood-pressure', 'skin-hair-and-hygiene',
  'allergy-relief', 'fungal-infections', 'joint-and-muscle-pain', 'asthma-and-copd',
  'skin-treatments', 'cholesterol-management', 'treatment-of-sneezing-and-runny-nose-due-to-allergies',
  'parasitic-infections', 'nausea-and-vomiting', 'heart-medicines', 'brain-and-nerve-care',
  'diarrhea', 'thyroid-and-hormones', 'indigestion', 'constipation', 'bone-joint-and-muscle-care',
  'skin-care', 'mind-care', 'sexual-wellness', 'stomach-pain-and-cramps',
  'kidney-and-urinary-medicines', 'constipation-and-piles',
  'headache-and-fever', 'headache-tablets', 'women-s-health-medicines', 'men-s-health-medicines',
  'eye-care', 'dry-eyes', 'treatment-of-dry-eyes', 'liver-care', 'liver-medicines', 'kidney-care',
  'respiratory-care', 'cardiac-care', 'heart-care', 'osteoarthritis', 'treatment-of-osteoarthritis',
  'treatment-of-osteoarthritis-of-knee-and-hip-joints', 'hypothyroidism', 'treatment-of-hypothyroidism',
  'hyperthyroidism', 'treatment-of-hyperthyroidism', 'scabies', 'treatment-of-scabies',
  'treatment-of-dandruff', 'dandruff', 'hair-loss', 'treatment-of-hair-loss', 'obesity',
  'weight-management', 'women-care', 'eye-and-ear-medicines', 'ear-care', 'oral-care',
  'treatment-of-mouth-ulcers', 'mouth-ulcers', 'piles-fissures-and-fistula', 'piles-and-fissures',
  'acidity', 'indigestion-and-bloating', 'sneezing-and-runny-nose-due-to-allergies',
  'irritable-bowel-syndrome', 'treatment-of-irritable-bowel-syndrome', 'mental-wellness', 'sleep',
  'wound-care', 'wound-care-and-dressings', 'burns', 'treatment-of-burns', 'anemia',
  'treatment-of-anemia', 'menopause', 'polycystic-ovarian-syndrome-pcos', 'polycystic-ovary-syndrome',
  'support-your-immunity', 'acne-and-pimples', 'cough-cold-and-fever', 'cough-syrups', 'pain-relief',
  'pain-management', 'pain-balm-and-ointment', 'treatment-of-gallbladder-stones',
  'treatment-of-meniere-s-disease', 'meniere-s-disease', 'treatment-of-benign-prostatic-hyperplasia',
  'benign-prostatic-hyperplasia', 'nutritional-deficiencies', 'treatment-of-nutritional-deficiencies',
  'appetite-stimulant', 'treatment-of-peripheral-vascular-disease', 'peripheral-vascular-disease',
  'viral-infections', 'ulcerative-colitis', 'treatment-of-ulcerative-colitis', 'female-infertility',
  'treatment-of-female-infertility', 'treatment-of-infertility', 'bleeding', 'post-delivery-bleeding',
  'stomach-ulcers', 'treatment-of-intestinal-ulcers', 'hair-fall-and-thinning', 'itching-and-rashes',
  'dry-and-itchy-skin', 'treatment-of-thrombophlebitis', 'prevention-of-blood-clots',
  'treatment-and-prevention-of-blood-clots', 'treatment-of-seizures', 'seizures',
  'attention-deficit-hyperactivity-disorder-adhd', 'cognitive-enhancer'
]);

if (!DATABASE_URL || !TYPESENSE_HOST || !TYPESENSE_API_KEY) {
  console.error('Missing required env vars: DATABASE_URL, TYPESENSE_HOST, TYPESENSE_API_KEY');
  process.exit(1);
}
if (!CATEGORY_ARG) {
  console.error(
    'Missing CATEGORY env var. Set it to one specific category, or "all" to run every category (smallest first). Valid categories:\n  ' +
      [...SYMPTOM_EMBEDDING_CATEGORIES].join('\n  ')
  );
  process.exit(1);
}
if (CATEGORY_ARG !== 'all' && !SYMPTOM_EMBEDDING_CATEGORIES.has(CATEGORY_ARG)) {
  console.error(`"${CATEGORY_ARG}" is not a valid symptom-embedding category. Valid options:\n  ` + [...SYMPTOM_EMBEDDING_CATEGORIES].join('\n  '));
  process.exit(1);
}

async function ensureEmbeddingFieldsExist() {
  const res = await fetch(`${TYPESENSE_PROTOCOL}://${TYPESENSE_HOST}:${TYPESENSE_PORT}/collections/medicines`, {
    method: 'PATCH',
    headers: { 'X-TYPESENSE-API-KEY': TYPESENSE_API_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      fields: [
        { name: 'symptomText', type: 'string', optional: true, index: false },
        {
          name: 'symptomEmbedding',
          type: 'float[]',
          optional: true,
          embed: { from: ['symptomText'], model_config: { model_name: 'ts/e5-small' } }
        }
      ]
    })
  });
  if (!res.ok) {
    const text = await res.text();
    if (!text.includes('already part of the schema')) throw new Error(`Failed to ensure embedding fields: ${res.status} ${text}`);
  }
}

function buildSymptomText(row) {
  const parts = [row.uses, row.sideeffects, row.description].filter((p) => p && p.trim().length > 0);
  return parts.length > 0 ? parts.join('. ') : undefined;
}

function toDocument(row) {
  return {
    id: row.id,
    brandName: row.brandname,
    genericName: row.genericname,
    manufacturer: row.manufacturer,
    slug: row.slug,
    activeIngredients: row.activeingredients ?? undefined,
    packForm: row.packform,
    packSize: row.packsize,
    category: row.category,
    schedule: row.schedule,
    departmentId: row.departmentid ?? undefined,
    categoryId: row.categoryid ?? undefined,
    subcategoryId: row.subcategoryid ?? undefined,
    isBanned: row.isbanned,
    isFeatured: row.isfeatured,
    updatedAt: Math.floor(new Date(row.updatedat).getTime() / 1000),
    symptomText: buildSymptomText(row)
  };
}

async function importBatch(documents) {
  const body = documents.map((d) => JSON.stringify(d)).join('\n');
  const res = await fetch(
    `${TYPESENSE_PROTOCOL}://${TYPESENSE_HOST}:${TYPESENSE_PORT}/collections/medicines/documents/import?action=upsert`,
    { method: 'POST', headers: { 'X-TYPESENSE-API-KEY': TYPESENSE_API_KEY, 'Content-Type': 'text/plain' }, body }
  );
  const text = await res.text();
  if (!res.ok) throw new Error(`Import failed: ${res.status} ${text}`);
  return text
    .trim()
    .split('\n')
    .map((line) => JSON.parse(line))
    .filter((r) => !r.success).length;
}

const SELECT_COLUMNS = `id, "brandName" as brandname, "genericName" as genericname, manufacturer, slug,
  "activeIngredients" as activeingredients, "packForm" as packform, "packSize" as packsize,
  category, schedule, "departmentId" as departmentid, "categoryId" as categoryid,
  "subcategoryId" as subcategoryid, "isBanned" as isbanned, "isFeatured" as isfeatured,
  "updatedAt" as updatedat, uses, "sideEffects" as sideeffects, description`;

async function backfillCategory(client, category) {
  const totalRes = await client.query('SELECT COUNT(*) FROM pharmacy."Medicine" WHERE category = $1', [category]);
  const total = parseInt(totalRes.rows[0].count, 10);
  console.log(`\n=== "${category}": ${total} medicines (batches of ${BATCH_SIZE}) ===`);

  let cursor = null;
  let processed = 0;
  let failed = 0;
  const startedAt = Date.now();

  while (true) {
    const { rows } = cursor
      ? await client.query(
          `SELECT ${SELECT_COLUMNS} FROM pharmacy."Medicine" WHERE category = $1 AND id > $2 ORDER BY id ASC LIMIT $3`,
          [category, cursor, BATCH_SIZE]
        )
      : await client.query(`SELECT ${SELECT_COLUMNS} FROM pharmacy."Medicine" WHERE category = $1 ORDER BY id ASC LIMIT $2`, [
          category,
          BATCH_SIZE
        ]);

    if (rows.length === 0) break;

    failed += await importBatch(rows.map(toDocument));
    processed += rows.length;
    cursor = rows[rows.length - 1].id;

    const ratePerSec = processed / ((Date.now() - startedAt) / 1000);
    const etaMin = Math.round((total - processed) / ratePerSec / 60);
    console.log(
      `${processed}/${total} (${((processed / total) * 100).toFixed(1)}%) — ${ratePerSec.toFixed(2)}/s — ETA ${etaMin}min — failed=${failed}`
    );
  }

  console.log(`Done with "${category}". Processed ${processed}, failed ${failed}, took ${((Date.now() - startedAt) / 60000).toFixed(1)}min`);
  return { category, processed, failed };
}

const client = new pg.Client(parseConnectionConfig(DATABASE_URL));
await client.connect();
await ensureEmbeddingFieldsExist();

let categoriesToRun;
if (CATEGORY_ARG === 'all') {
  // Query real counts and sort ascending — smallest/fastest categories run
  // first, the largest (pain-and-fever, ~72k) runs last. This is exactly
  // the "fewer first, remaining later" ordering.
  const { rows } = await client.query(
    `SELECT category, COUNT(*) as count FROM pharmacy."Medicine"
     WHERE category = ANY($1) GROUP BY category ORDER BY count ASC`,
    [[...SYMPTOM_EMBEDDING_CATEGORIES]]
  );
  categoriesToRun = rows.map((r) => r.category);
  console.log('Running ALL categories, smallest first:');
  rows.forEach((r) => console.log(`  ${r.category}: ${r.count}`));
} else {
  categoriesToRun = [CATEGORY_ARG];
}

const overallStartedAt = Date.now();
const results = [];
for (const category of categoriesToRun) {
  results.push(await backfillCategory(client, category));
}

console.log(`\n=== ALL DONE: ${categoriesToRun.length} categor${categoriesToRun.length === 1 ? 'y' : 'ies'} in ${((Date.now() - overallStartedAt) / 60000).toFixed(1)}min ===`);
const totalFailed = results.reduce((sum, r) => sum + r.failed, 0);
results.forEach((r) => console.log(`  ${r.category}: ${r.processed} processed, ${r.failed} failed`));

await client.end();
process.exit(totalFailed > 0 ? 1 : 0);
