// Backfill of the `vendor_medicines` Typesense collection (geosearch) from
// the VendorMedicine + Vendor tables. Mirrors backfillAllVendorMedicines()
// in src/services/vendor-medicine-search.service.ts, self-contained.
//
// Usage: DATABASE_URL=... TYPESENSE_HOST=... TYPESENSE_API_KEY=... node backfill-vendor-medicines.mjs

import pg from 'pg';

// See backfill-medicines.mjs for why this parsing (rather than passing
// sslmode=require straight through) is needed — pg's connection-string SSL
// parsing otherwise overrides an explicit `ssl` option and enforces strict
// cert verification, which fails against DigitalOcean's managed Postgres cert.
function parseConnectionConfig(databaseUrl) {
  const url = new URL(databaseUrl);
  return {
    host: url.hostname,
    port: Number(url.port),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: url.pathname.replace(/^\//, ''),
    ssl: { rejectUnauthorized: false }
  };
}

const DATABASE_URL = process.env.DATABASE_URL;
const TYPESENSE_HOST = process.env.TYPESENSE_HOST;
const TYPESENSE_PORT = process.env.TYPESENSE_PORT || '443';
const TYPESENSE_PROTOCOL = process.env.TYPESENSE_PROTOCOL || 'https';
const TYPESENSE_API_KEY = process.env.TYPESENSE_API_KEY;
const BATCH_SIZE = 1000;

if (!DATABASE_URL || !TYPESENSE_HOST || !TYPESENSE_API_KEY) {
  console.error('Missing required env vars: DATABASE_URL, TYPESENSE_HOST, TYPESENSE_API_KEY');
  process.exit(1);
}

const VENDOR_MEDICINES_SCHEMA = {
  name: 'vendor_medicines',
  fields: [
    { name: 'medicineId', type: 'string', optional: true, facet: true },
    { name: 'vendorId', type: 'string', facet: true },
    { name: 'brandText', type: 'string' },
    { name: 'genericName', type: 'string', optional: true },
    { name: 'manufacturer', type: 'string', optional: true },
    { name: 'sellPricePaise', type: 'int32', sort: true },
    { name: 'mrpPaise', type: 'int32' },
    { name: 'status', type: 'string', facet: true },
    { name: 'vendorDisplayName', type: 'string' },
    { name: 'vendorShopCity', type: 'string', facet: true },
    { name: 'vendorShopState', type: 'string', facet: true },
    { name: 'location', type: 'geopoint', optional: true }
  ]
};

function toDocument(row) {
  return {
    id: row.id,
    medicineId: row.medicineid ?? undefined,
    vendorId: row.vendorid,
    brandText: row.brandtext,
    genericName: row.genericname ?? undefined,
    manufacturer: row.manufacturer ?? undefined,
    sellPricePaise: row.sellpricepaise,
    mrpPaise: row.mrppaise,
    status: row.status,
    vendorDisplayName: row.vendordisplayname,
    vendorShopCity: row.vendorshopcity,
    vendorShopState: row.vendorshopstate,
    location: row.latitude !== null && row.longitude !== null ? [row.latitude, row.longitude] : undefined
  };
}

async function typesenseRequest(method, path, body) {
  const res = await fetch(`${TYPESENSE_PROTOCOL}://${TYPESENSE_HOST}:${TYPESENSE_PORT}${path}`, {
    method,
    headers: { 'X-TYPESENSE-API-KEY': TYPESENSE_API_KEY, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Typesense ${method} ${path} failed: ${res.status} ${text}`);
  }
  return res.json();
}

async function ensureCollectionExists() {
  try {
    await typesenseRequest('POST', '/collections', VENDOR_MEDICINES_SCHEMA);
    console.log('Created "vendor_medicines" collection.');
  } catch (err) {
    if (String(err.message).includes('already exists')) return;
    throw err;
  }
}

async function importBatch(documents) {
  const body = documents.map((d) => JSON.stringify(d)).join('\n');
  const res = await fetch(
    `${TYPESENSE_PROTOCOL}://${TYPESENSE_HOST}:${TYPESENSE_PORT}/collections/vendor_medicines/documents/import?action=upsert`,
    { method: 'POST', headers: { 'X-TYPESENSE-API-KEY': TYPESENSE_API_KEY, 'Content-Type': 'text/plain' }, body }
  );
  const text = await res.text();
  if (!res.ok) throw new Error(`Import failed: ${res.status} ${text}`);
  return text
    .trim()
    .split('\n')
    .map((line) => JSON.parse(line))
    .filter((r) => !r.success).length;
}

// See backfill-medicines.mjs for why rejectUnauthorized: false is needed here.
const client = new pg.Client(parseConnectionConfig(DATABASE_URL));
await client.connect();
await ensureCollectionExists();

const totalRes = await client.query('SELECT COUNT(*) FROM pharmacy."VendorMedicine"');
const total = parseInt(totalRes.rows[0].count, 10);
console.log(`Backfilling ${total} vendor medicines (batches of ${BATCH_SIZE})...`);

const SELECT_SQL = `
  SELECT vm.id, vm."medicineId" as medicineid, vm."vendorId" as vendorid, vm."brandText" as brandtext,
         vm."genericName" as genericname, vm.manufacturer, vm."sellPricePaise" as sellpricepaise,
         vm."mrpPaise" as mrppaise, vm.status,
         v."displayName" as vendordisplayname, v."shopCity" as vendorshopcity, v."shopState" as vendorshopstate,
         v.latitude, v.longitude
  FROM pharmacy."VendorMedicine" vm
  JOIN pharmacy."Vendor" v ON v.id = vm."vendorId"`;

let cursor = null;
let processed = 0;
let failed = 0;
const startedAt = Date.now();

while (true) {
  const { rows } = cursor
    ? await client.query(`${SELECT_SQL} WHERE vm.id > $1 ORDER BY vm.id ASC LIMIT $2`, [cursor, BATCH_SIZE])
    : await client.query(`${SELECT_SQL} ORDER BY vm.id ASC LIMIT $1`, [BATCH_SIZE]);

  if (rows.length === 0) break;

  failed += await importBatch(rows.map(toDocument));
  processed += rows.length;
  cursor = rows[rows.length - 1].id;

  const ratePerSec = processed / ((Date.now() - startedAt) / 1000);
  console.log(`${processed}/${total} (${((processed / total) * 100).toFixed(1)}%) — ${ratePerSec.toFixed(0)}/s — failed=${failed}`);
}

console.log(`Done. Processed ${processed}, failed ${failed}, took ${((Date.now() - startedAt) / 1000).toFixed(1)}s`);
await client.end();
process.exit(failed > 0 ? 1 : 0);
