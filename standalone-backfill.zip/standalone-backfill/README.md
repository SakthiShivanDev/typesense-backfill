# Standalone Typesense Backfill Scripts

Self-contained — no dependency on the main `medivoy-pharmacy.api` repo, no Prisma. Just `pg` (Postgres driver) and Node's built-in `fetch`. Copy this whole folder to any server with network access to your Postgres database and Typesense server, and run it there.

## Setup

```bash
npm install
cp .env.example .env
# edit .env with your real DATABASE_URL, TYPESENSE_HOST, TYPESENSE_API_KEY
```

Every script reads its config from environment variables — either export them directly, or use a `.env` loader (e.g. `node --env-file=.env script.mjs` on Node 20.6+, or `npx dotenv-cli -e .env -- node script.mjs`).

## Run order

Run these in order — each is idempotent (safe to re-run; uses `upsert`), so if one fails partway through, just run it again.

### 1. Full medicines backfill (~13 min for ~744k medicines, measured)

```bash
node --env-file=.env backfill-medicines.mjs
```

Creates the `medicines` Typesense collection if it doesn't exist, then indexes every row in the `Medicine` table (plain text — no embeddings yet).

### 2. Vendor medicines backfill (geosearch — seconds, scales with your vendor listing count)

```bash
node --env-file=.env backfill-vendor-medicines.mjs
```

Creates the `vendor_medicines` collection and indexes every `VendorMedicine` row joined with its vendor's location.

### 3. Synonyms (seconds)

```bash
node --env-file=.env seed-synonyms.mjs
```

No database needed for this one — pure Typesense REST calls. Edit `SYNONYM_SETS` in the script to add more terms before running.

### 4. Symptom embeddings — run this LAST and deliberately

**This one is slow and resource-intensive — read before running.** Each document needs real ML inference on the Typesense server (measured ~3.9 docs/sec — 25x slower than the plain-text backfills above), not just indexing.

**Option A — one category at a time (safest, most control):**

```bash
CATEGORY=pain-and-fever node --env-file=.env backfill-symptom-embeddings.mjs
```

Run one, let it finish, check in on your server's memory (see below), then run the next.

**Option B — every category in one run, smallest first:**

```bash
CATEGORY=all node --env-file=.env backfill-symptom-embeddings.mjs
```

Queries real per-category counts from your database, sorts them smallest → largest, and runs through all 119 sequentially in that order — so the smaller categories all complete and give you working symptom search relatively quickly, and the biggest ones (`pain-and-fever` at ~72k and `bacterial-infections` at ~89k) run last, back-to-back, without you having to babysit each category invocation individually. Covers 423,903 medicines total. Expect the full run to take **~30 hours total** (measured ~3.9 docs/sec) — this is meant to be started in a real background session (`tmux`, `screen`, `nohup ... &`, a systemd service, etc.) on a server you're not going to close, not run-and-wait-in-a-terminal.

Either way, the script refuses to run without a valid `CATEGORY` (or `all`) and prints the full list of valid category names if you get it wrong.

## What each script actually does

All four scripts mirror the exact logic in the main repo's `src/services/search-index.service.ts` and `src/services/vendor-medicine-search.service.ts` — they were copied out and made self-contained specifically so they don't need Prisma or the rest of the repo to run. If those service files change in the future, these standalone copies will drift and need to be manually re-synced.

## Monitoring while it runs

Each script logs progress (`X/total (Y%) — Z/s — failed=N`) as it goes. For the symptom-embeddings backfill specifically, also keep an eye on your Typesense server's memory (`GET /metrics.json` with your API key) if it's a small/resource-constrained box — embeddings add real memory pressure, and a server with no swap configured can crash rather than degrade gracefully if it runs out.
