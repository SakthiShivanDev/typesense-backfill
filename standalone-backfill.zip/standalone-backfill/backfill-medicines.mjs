// Full plain-text (no embeddings) backfill of the `medicines` Typesense
// collection from the Medicine table. Mirrors backfillAllMedicines() in
// src/services/search-index.service.ts, but self-contained — no Prisma, no
// dependency on the main repo, just `pg` and built-in fetch.
//
// Usage:
//   DATABASE_URL=... TYPESENSE_HOST=... TYPESENSE_API_KEY=... node backfill-medicines.mjs
// (or `npm install && npm run backfill:medicines` with a .env loader of your choice)

import pg from 'pg';

// pg's connection-string SSL parsing takes precedence over an explicit `ssl`
// option when the string itself contains sslmode=require, so passing both
// leaves strict cert verification in place (confirmed via a real
// "self-signed certificate in certificate chain" error in testing — managed
// Postgres providers like DigitalOcean use a cert chain not in Node's
// default trust store). Parsing to a plain config object and dropping
// sslmode from it entirely is what actually works.
function parseConnectionConfig(databaseUrl) {
  const url = new URL(databaseUrl);
  return {
    host: url.hostname,
    port: Number(url.port),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: url.pathname.replace(/^\//, ''),
    ssl: { rejectUnauthorized: false }
  };
}

const DATABASE_URL = process.env.DATABASE_URL;
const TYPESENSE_HOST = process.env.TYPESENSE_HOST;
const TYPESENSE_PORT = process.env.TYPESENSE_PORT || '443';
const TYPESENSE_PROTOCOL = process.env.TYPESENSE_PROTOCOL || 'https';
const TYPESENSE_API_KEY = process.env.TYPESENSE_API_KEY;
const BATCH_SIZE = 1000; // plain-text indexing is fast — no embedding inference, safe to batch large

if (!DATABASE_URL || !TYPESENSE_HOST || !TYPESENSE_API_KEY) {
  console.error('Missing required env vars: DATABASE_URL, TYPESENSE_HOST, TYPESENSE_API_KEY');
  process.exit(1);
}

// Same schema as medicinesIndex in src/services/search-index.service.ts.
// Included here so this script can create the collection on a fresh
// Typesense instance if it doesn't already exist.
const MEDICINES_SCHEMA = {
  name: 'medicines',
  fields: [
    { name: 'brandName', type: 'string' },
    { name: 'genericName', type: 'string' },
    { name: 'manufacturer', type: 'string' },
    { name: 'slug', type: 'string' },
    { name: 'activeIngredients', type: 'string', optional: true },
    { name: 'packForm', type: 'string' },
    { name: 'packSize', type: 'string' },
    { name: 'category', type: 'string', facet: true },
    { name: 'schedule', type: 'string', facet: true },
    { name: 'departmentId', type: 'string', facet: true, optional: true },
    { name: 'categoryId', type: 'string', facet: true, optional: true },
    { name: 'subcategoryId', type: 'string', facet: true, optional: true },
    { name: 'isBanned', type: 'bool', facet: true },
    { name: 'isFeatured', type: 'bool', facet: true },
    { name: 'updatedAt', type: 'int64', sort: true },
    { name: 'symptomText', type: 'string', optional: true, index: false },
    {
      name: 'symptomEmbedding',
      type: 'float[]',
      optional: true,
      embed: { from: ['symptomText'], model_config: { model_name: 'ts/e5-small' } }
    }
  ]
};

// Must match SYMPTOM_EMBEDDING_CATEGORIES in src/services/search-index.service.ts exactly.
// Rebuilt from a full scan of all 982 distinct category values (the original
// 30 came from only the top 60 by count, which silently dropped real symptom
// categories like "headache-and-fever", 487 medicines). Now 119 categories,
// covering 423,903 medicines.
const SYMPTOM_EMBEDDING_CATEGORIES = new Set([
  'bacterial-infections', 'pain-and-fever', 'acidity-and-heartburn', 'diabetes-medicines',
  'cough-and-cold', 'anxiety-sleep-and-mood', 'blood-pressure', 'skin-hair-and-hygiene',
  'allergy-relief', 'fungal-infections', 'joint-and-muscle-pain', 'asthma-and-copd',
  'skin-treatments', 'cholesterol-management', 'treatment-of-sneezing-and-runny-nose-due-to-allergies',
  'parasitic-infections', 'nausea-and-vomiting', 'heart-medicines', 'brain-and-nerve-care',
  'diarrhea', 'thyroid-and-hormones', 'indigestion', 'constipation', 'bone-joint-and-muscle-care',
  'skin-care', 'mind-care', 'sexual-wellness', 'stomach-pain-and-cramps',
  'kidney-and-urinary-medicines', 'constipation-and-piles',
  'headache-and-fever', 'headache-tablets', 'women-s-health-medicines', 'men-s-health-medicines',
  'eye-care', 'dry-eyes', 'treatment-of-dry-eyes', 'liver-care', 'liver-medicines', 'kidney-care',
  'respiratory-care', 'cardiac-care', 'heart-care', 'osteoarthritis', 'treatment-of-osteoarthritis',
  'treatment-of-osteoarthritis-of-knee-and-hip-joints', 'hypothyroidism', 'treatment-of-hypothyroidism',
  'hyperthyroidism', 'treatment-of-hyperthyroidism', 'scabies', 'treatment-of-scabies',
  'treatment-of-dandruff', 'dandruff', 'hair-loss', 'treatment-of-hair-loss', 'obesity',
  'weight-management', 'women-care', 'eye-and-ear-medicines', 'ear-care', 'oral-care',
  'treatment-of-mouth-ulcers', 'mouth-ulcers', 'piles-fissures-and-fistula', 'piles-and-fissures',
  'acidity', 'indigestion-and-bloating', 'sneezing-and-runny-nose-due-to-allergies',
  'irritable-bowel-syndrome', 'treatment-of-irritable-bowel-syndrome', 'mental-wellness', 'sleep',
  'wound-care', 'wound-care-and-dressings', 'burns', 'treatment-of-burns', 'anemia',
  'treatment-of-anemia', 'menopause', 'polycystic-ovarian-syndrome-pcos', 'polycystic-ovary-syndrome',
  'support-your-immunity', 'acne-and-pimples', 'cough-cold-and-fever', 'cough-syrups', 'pain-relief',
  'pain-management', 'pain-balm-and-ointment', 'treatment-of-gallbladder-stones',
  'treatment-of-meniere-s-disease', 'meniere-s-disease', 'treatment-of-benign-prostatic-hyperplasia',
  'benign-prostatic-hyperplasia', 'nutritional-deficiencies', 'treatment-of-nutritional-deficiencies',
  'appetite-stimulant', 'treatment-of-peripheral-vascular-disease', 'peripheral-vascular-disease',
  'viral-infections', 'ulcerative-colitis', 'treatment-of-ulcerative-colitis', 'female-infertility',
  'treatment-of-female-infertility', 'treatment-of-infertility', 'bleeding', 'post-delivery-bleeding',
  'stomach-ulcers', 'treatment-of-intestinal-ulcers', 'hair-fall-and-thinning', 'itching-and-rashes',
  'dry-and-itchy-skin', 'treatment-of-thrombophlebitis', 'prevention-of-blood-clots',
  'treatment-and-prevention-of-blood-clots', 'treatment-of-seizures', 'seizures',
  'attention-deficit-hyperactivity-disorder-adhd', 'cognitive-enhancer'
]);

function buildSymptomText(row) {
  if (!SYMPTOM_EMBEDDING_CATEGORIES.has(row.category)) return undefined;
  const parts = [row.uses, row.sideeffects, row.description].filter((p) => p && p.trim().length > 0);
  return parts.length > 0 ? parts.join('. ') : undefined;
}

function toDocument(row) {
  return {
    id: row.id,
    brandName: row.brandname,
    genericName: row.genericname,
    manufacturer: row.manufacturer,
    slug: row.slug,
    activeIngredients: row.activeingredients ?? undefined,
    packForm: row.packform,
    packSize: row.packsize,
    category: row.category,
    schedule: row.schedule,
    departmentId: row.departmentid ?? undefined,
    categoryId: row.categoryid ?? undefined,
    subcategoryId: row.subcategoryid ?? undefined,
    isBanned: row.isbanned,
    isFeatured: row.isfeatured,
    updatedAt: Math.floor(new Date(row.updatedat).getTime() / 1000),
    symptomText: buildSymptomText(row)
  };
}

async function typesenseRequest(method, path, body) {
  const res = await fetch(`${TYPESENSE_PROTOCOL}://${TYPESENSE_HOST}:${TYPESENSE_PORT}${path}`, {
    method,
    headers: { 'X-TYPESENSE-API-KEY': TYPESENSE_API_KEY, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Typesense ${method} ${path} failed: ${res.status} ${text}`);
  }
  return res.json();
}

async function ensureCollectionExists() {
  try {
    await typesenseRequest('POST', '/collections', MEDICINES_SCHEMA);
    console.log('Created "medicines" collection.');
  } catch (err) {
    if (String(err.message).includes('already exists')) return;
    throw err;
  }
}

async function importBatch(documents) {
  const body = documents.map((d) => JSON.stringify(d)).join('\n');
  const res = await fetch(
    `${TYPESENSE_PROTOCOL}://${TYPESENSE_HOST}:${TYPESENSE_PORT}/collections/medicines/documents/import?action=upsert`,
    { method: 'POST', headers: { 'X-TYPESENSE-API-KEY': TYPESENSE_API_KEY, 'Content-Type': 'text/plain' }, body }
  );
  const text = await res.text();
  if (!res.ok) throw new Error(`Import failed: ${res.status} ${text}`);
  return text
    .trim()
    .split('\n')
    .map((line) => JSON.parse(line))
    .filter((r) => !r.success).length;
}

// rejectUnauthorized: false — managed Postgres providers (DigitalOcean here)
// use a cert chain not in Node's default trust store; newer pg versions
// enforce strict verification for sslmode=require where older ones didn't
// (confirmed via a real "self-signed certificate in certificate chain"
// error in testing). Still encrypted in transit, just not strictly
// cert-verified — matches how Prisma's own connector handles this URL.
const client = new pg.Client(parseConnectionConfig(DATABASE_URL));
await client.connect();
await ensureCollectionExists();

const totalRes = await client.query('SELECT COUNT(*) FROM pharmacy."Medicine"');
const total = parseInt(totalRes.rows[0].count, 10);
console.log(`Backfilling ${total} medicines (batches of ${BATCH_SIZE})...`);

const SELECT_COLUMNS = `id, "brandName" as brandname, "genericName" as genericname, manufacturer, slug,
  "activeIngredients" as activeingredients, "packForm" as packform, "packSize" as packsize,
  category, schedule, "departmentId" as departmentid, "categoryId" as categoryid,
  "subcategoryId" as subcategoryid, "isBanned" as isbanned, "isFeatured" as isfeatured,
  "updatedAt" as updatedat, uses, "sideEffects" as sideeffects, description`;

let cursor = null;
let processed = 0;
let failed = 0;
const startedAt = Date.now();

while (true) {
  const { rows } = cursor
    ? await client.query(
        `SELECT ${SELECT_COLUMNS} FROM pharmacy."Medicine" WHERE id > $1 ORDER BY id ASC LIMIT $2`,
        [cursor, BATCH_SIZE]
      )
    : await client.query(`SELECT ${SELECT_COLUMNS} FROM pharmacy."Medicine" ORDER BY id ASC LIMIT $1`, [BATCH_SIZE]);

  if (rows.length === 0) break;

  failed += await importBatch(rows.map(toDocument));
  processed += rows.length;
  cursor = rows[rows.length - 1].id;

  const ratePerSec = processed / ((Date.now() - startedAt) / 1000);
  console.log(`${processed}/${total} (${((processed / total) * 100).toFixed(1)}%) — ${ratePerSec.toFixed(0)}/s — failed=${failed}`);
}

console.log(`Done. Processed ${processed}, failed ${failed}, took ${((Date.now() - startedAt) / 1000).toFixed(1)}s`);
await client.end();
process.exit(failed > 0 ? 1 : 0);
