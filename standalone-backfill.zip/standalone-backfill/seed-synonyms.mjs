// Seeds the starter synonym set and links it to the `medicines` collection.
// Pure Typesense REST calls — no database needed at all. Mirrors
// seedStarterSynonyms() in src/services/search-index.service.ts.
//
// Usage: TYPESENSE_HOST=... TYPESENSE_API_KEY=... node seed-synonyms.mjs

const TYPESENSE_HOST = process.env.TYPESENSE_HOST;
const TYPESENSE_PORT = process.env.TYPESENSE_PORT || '443';
const TYPESENSE_PROTOCOL = process.env.TYPESENSE_PROTOCOL || 'https';
const TYPESENSE_API_KEY = process.env.TYPESENSE_API_KEY;

if (!TYPESENSE_HOST || !TYPESENSE_API_KEY) {
  console.error('Missing required env vars: TYPESENSE_HOST, TYPESENSE_API_KEY');
  process.exit(1);
}

// Colloquial/abbreviated terms that never appear as a substring anywhere in
// the catalog data. Brand<->generic pairs (Crocin<->Paracetamol) are
// intentionally excluded — already covered by brandName/genericName both
// being indexed, searchable fields. Add more sets here as needed.
const SYNONYM_SETS = {
  paracetamol: ['pcm', 'paracetamol', 'acetaminophen', 'tylenol'],
  ors: ['ors', 'oral rehydration salts', 'oral rehydration solution'],
  'vitamin-c': ['vitamin c', 'vit c', 'ascorbic acid'],
  'vitamin-d': ['vitamin d', 'vit d', 'cholecalciferol'],
  'blood-pressure': ['bp', 'blood pressure'],
  'over-the-counter': ['otc', 'over the counter']
};

async function typesenseRequest(method, path, body) {
  const res = await fetch(`${TYPESENSE_PROTOCOL}://${TYPESENSE_HOST}:${TYPESENSE_PORT}${path}`, {
    method,
    headers: { 'X-TYPESENSE-API-KEY': TYPESENSE_API_KEY, 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Typesense ${method} ${path} failed: ${res.status} ${text}`);
  }
  return res.json();
}

for (const [id, synonyms] of Object.entries(SYNONYM_SETS)) {
  await typesenseRequest('PUT', `/synonym_sets/${id}`, { items: [{ id, synonyms }] });
  console.log(`Upserted synonym set "${id}":`, synonyms.join(', '));
}

await typesenseRequest('PATCH', '/collections/medicines', { synonym_sets: Object.keys(SYNONYM_SETS) });
console.log(`Done. ${Object.keys(SYNONYM_SETS).length} synonym sets linked to the medicines collection.`);
