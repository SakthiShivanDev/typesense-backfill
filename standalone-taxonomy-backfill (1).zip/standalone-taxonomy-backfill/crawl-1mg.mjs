// Crawls Tata 1mg's therapeutic-class tree ONCE and saves every drug together
// with the department (parent class) and category (class) 1mg files it under,
// plus its composition and manufacturer.
// backfill-competitor-taxonomy.mjs then maps our medicines against this local
// index instead of searching 1mg once per medicine.
//
// Output (INDEX_DIR, default ./index):
//   1mg-tree.json      parent class -> child classes, as published by 1mg
//   1mg.jsonl          one line per drug: { slug, name, manufacturer, pack, composition, department, category, classId }
//   1mg-progress.json  resume state (class id -> last finished page)
//
// Usage:
//   node crawl-1mg.mjs                       # whole tree, resumable
//   CRAWL_CLASS_LIMIT=3 node crawl-1mg.mjs   # first 3 classes only (smoke test)
//   RPS_1MG=2 node crawl-1mg.mjs
//
// If 1mg answers 403 from your server, run this on a machine where 1mg opens
// normally (e.g. an office PC) and copy the resulting ./index folder to the server —
// the mapper only reads the files.

import { appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { BROWSER_HEADERS, RateLimiter, httpGet } from './lib/core.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const INDEX_DIR = process.env.INDEX_DIR || join(__dirname, 'index');
const CLASS_LIMIT = Number.parseInt(process.env.CRAWL_CLASS_LIMIT ?? '', 10) || Infinity;
const CONCURRENCY = Number.parseInt(process.env.CRAWL_CONCURRENCY ?? '', 10) || 3;
const PAGE_SIZE = 20;
const REQUEST_HEADERS = { ...BROWSER_HEADERS, referer: 'https://www.1mg.com/' };

const limiter = new RateLimiter('1mg-crawl', Number(process.env.RPS_1MG ?? 3));
const TREE_FILE = join(INDEX_DIR, '1mg-tree.json');
const DRUGS_FILE = join(INDEX_DIR, '1mg.jsonl');
const PROGRESS_FILE = join(INDEX_DIR, '1mg-progress.json');

mkdirSync(INDEX_DIR, { recursive: true });

/** The index page embeds the whole tree as escaped JSON under "originalData". */
function extractTree(html) {
  const key = html.indexOf('originalData');
  if (key < 0) throw new Error('originalData not found on the 1mg therapeutic-classes page');
  const start = html.indexOf('[', key);
  let depth = 0;
  let end = -1;
  for (let i = start; i < html.length; i++) {
    const ch = html[i];
    if (ch === '[') depth++;
    else if (ch === ']' && --depth === 0) {
      end = i;
      break;
    }
  }
  if (end < 0) throw new Error('could not bracket-match the class tree');
  const raw = html.slice(start, end + 1);
  // Embedded inside a JSON string, so quotes arrive escaped (\"); unescape before parsing.
  const parsed = JSON.parse(raw.includes('\\"') ? raw.replace(/\\"/g, '"').replace(/\\\\/g, '\\') : raw);
  return parsed
    .filter((p) => p.display_name)
    .map((p) => ({
      id: p.id,
      name: p.display_name,
      children: (p.children ?? []).map((c) => ({ id: c.id, name: c.display_name, slug: c.slug }))
    }));
}

async function loadTree() {
  if (existsSync(TREE_FILE)) return JSON.parse(readFileSync(TREE_FILE, 'utf8'));
  const { status, text } = await httpGet('https://www.1mg.com/drugs-therapeutic-classes', limiter, {
    maxBytes: 3_000_000,
    headers: REQUEST_HEADERS
  });
  if (status !== 200) throw new Error(`class index returned HTTP ${status}`);
  const tree = extractTree(text);
  writeFileSync(TREE_FILE, JSON.stringify(tree, null, 2));
  return tree;
}

const progress = existsSync(PROGRESS_FILE) ? JSON.parse(readFileSync(PROGRESS_FILE, 'utf8')) : {};
const saveProgress = () => writeFileSync(PROGRESS_FILE, JSON.stringify(progress));

// The class page carries its drug list as JSON escaped inside window.__ROUTER_INITIAL_DATA__
// (each drug: manufacturer_name, name, pack_size_label, slug, short_composition, ...).
// Composition lets the mapper place catalog medicines 1mg doesn't list by name (same salt -> same class).
const SKU =
  /"manufacturer_name":"([^"]*)"[^{}]*?"name":"([^"]*)"[^{}]*?"pack_size_label":"([^"]*)"[\s\S]{0,400}?"slug":"(\/drugs\/[^"]+)","short_composition":"([^"]*)"/g;

function parseDrugs(html) {
  const from = html.indexOf('__ROUTER_INITIAL_DATA__');
  const data = (from >= 0 ? html.slice(from) : html).replace(/\\"/g, '"');
  const seen = new Set();
  const drugs = [];
  for (const m of data.matchAll(SKU)) {
    if (seen.has(m[4])) continue;
    seen.add(m[4]);
    drugs.push({ slug: m[4], name: m[2], manufacturer: m[1], pack: m[3], composition: m[5] });
  }
  return drugs;
}

async function crawlClass(parent, child, stats) {
  const state = progress[child.id] ?? { page: 0, total: null };
  if (state.total !== null && state.page * PAGE_SIZE >= state.total) return; // finished earlier

  for (let page = state.page + 1; ; page++) {
    const url = `https://www.1mg.com/drugs-therapeutic-classes/drug-class-${child.id}?page=${page}`;
    const { status, text } = await httpGet(url, limiter, { maxBytes: 3_000_000, headers: REQUEST_HEADERS });
    if (status >= 400) throw new Error(`HTTP ${status} for ${url}`);
    const total = Number(text.match(/total_count\\?":(\d+)/)?.[1] ?? 0);
    const drugs = parseDrugs(text);

    if (drugs.length) {
      appendFileSync(
        DRUGS_FILE,
        drugs
          .map((d) => JSON.stringify({ ...d, department: parent.name, category: child.name, classId: child.id }))
          .join('\n') + '\n'
      );
    }
    stats.drugs += drugs.length;
    stats.pages++;
    progress[child.id] = { page, total };
    saveProgress();
    if (!drugs.length || page * PAGE_SIZE >= total) return;
  }
}

async function main() {
  const tree = await loadTree();
  const classes = tree.flatMap((parent) => parent.children.map((child) => ({ parent, child }))).slice(0, CLASS_LIMIT);
  console.log(`1mg tree: ${tree.length} parent classes, ${classes.length} classes to crawl`);

  const stats = { drugs: 0, pages: 0, classesDone: 0, failed: [] };
  const queue = [...classes];
  const started = Date.now();
  const timer = setInterval(() => {
    process.stdout.write(
      `\r  classes ${stats.classesDone}/${classes.length} | pages ${stats.pages} | drugs ${stats.drugs} | ` +
        `${((Date.now() - started) / 60000).toFixed(1)} min   `
    );
  }, 5000);

  await Promise.all(
    Array.from({ length: CONCURRENCY }, async () => {
      while (queue.length) {
        const { parent, child } = queue.shift();
        try {
          await crawlClass(parent, child, stats);
        } catch (error) {
          stats.failed.push(`${child.name} (${child.id}): ${error.message}`);
        }
        stats.classesDone++;
      }
    })
  );
  clearInterval(timer);
  console.log(`\nDone: ${stats.pages} pages, ${stats.drugs} drug rows written to ${DRUGS_FILE}`);
  if (stats.failed.length) {
    console.log(`${stats.failed.length} classes failed (re-run to resume them):`);
    stats.failed.slice(0, 10).forEach((f) => console.log('  ' + f));
    if (stats.failed.some((f) => /403|429|disabled/.test(f))) {
      console.log(
        [
          '',
          "1mg is blocking this machine's IP address (typical for cloud servers). Options:",
          '  - run this crawl on a PC where 1mg opens normally and copy the resulting ./index folder here, or',
          '  - set PROXY_URL=http://user:pass@host:port in .env (needs npm install for the undici package) and re-run.',
          'Progress is saved; re-running continues where it stopped.'
        ].join('\n')
      );
    }
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
