// Crawls Apollo Pharmacy's catalog into a local index of products and the
// 3-level class (classifier_1 > classifier_2 > classifier_3) Apollo files them under.
//
// Apollo's storefront uses a public GraphQL query, getAplCategoryProducts, with an
// anonymous access token issued to any visitor. Two ways in, both used here:
//   1. category_url  — every shop-by-category page (OTC, wellness, baby, devices, ...)
//   2. composition   — every product containing a given salt (this is how Rx medicines are listed)
// Products carry no composition field, so a product's composition is rebuilt from the
// salts it was listed under (a Paracetamol + Caffeine tablet appears under both).
//
// Salts to query come from (in order): SALTS_FILE, or the union of
//   - ingredient names in the crawled 1mg / Netmeds indexes, and
//   - (when DATABASE_URL is set) clean ingredient names that occur >= SALT_MIN_COUNT times in our catalog.
//
// Output (INDEX_DIR, default ./index):
//   apollo-raw.jsonl        one line per product per query (resume state)
//   apollo-progress.json    finished queries
//   apollo.jsonl            merged, de-duplicated product index — what the mapper reads
//
// Usage:
//   node crawl-apollo.mjs
//   CRAWL_QUERY_LIMIT=20 node crawl-apollo.mjs     # smoke test: first 20 queries
//   SKIP_CATEGORIES=true node crawl-apollo.mjs     # only the salt (Rx medicine) queries
//   MERGE_ONLY=true node crawl-apollo.mjs          # rebuild apollo.jsonl from apollo-raw.jsonl

import { appendFileSync, createReadStream, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { createInterface } from 'node:readline';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';
import { RateLimiter, httpGet, saltNames } from './lib/core.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const INDEX_DIR = process.env.INDEX_DIR || join(__dirname, 'index');
const QUERY_LIMIT = Number.parseInt(process.env.CRAWL_QUERY_LIMIT ?? '', 10) || Infinity;
const CONCURRENCY = Number.parseInt(process.env.CRAWL_CONCURRENCY ?? '', 10) || 4;
const SALT_MIN_COUNT = Number.parseInt(process.env.SALT_MIN_COUNT ?? '', 10) || 5;
const PAGE_SIZE = 40; // server-side cap; larger sizes still return 40
const truthy = (v) => ['1', 'true', 'yes'].includes((v ?? '').toLowerCase());
const SKIP_CATEGORIES = truthy(process.env.SKIP_CATEGORIES);
const MERGE_ONLY = truthy(process.env.MERGE_ONLY);

const RAW_FILE = join(INDEX_DIR, 'apollo-raw.jsonl');
const PROGRESS_FILE = join(INDEX_DIR, 'apollo-progress.json');
const OUT_FILE = join(INDEX_DIR, 'apollo.jsonl');
const limiter = new RateLimiter('apollo-crawl', Number(process.env.RPS_APOLLO ?? 4));

mkdirSync(INDEX_DIR, { recursive: true });

/* ───────────── anonymous session ───────────── */

const deviceId = randomUUID();
const BASE_HEADERS = {
  origin: 'https://www.apollopharmacy.in',
  referer: 'https://www.apollopharmacy.in/',
  'x-device-id': deviceId
};
let token = null;
let tokenExpiresAt = 0;

async function ensureToken(force = false) {
  if (!force && token && Date.now() < tokenExpiresAt) return token;
  const { status, text } = await httpGet(
    `https://apigateway.apollo247.in/auth-service/accessToken?_nonce=${randomUUID()}`,
    limiter,
    { headers: { ...BASE_HEADERS, accept: 'application/json' } }
  );
  if (status !== 200) throw new Error(`token request failed: HTTP ${status}`);
  const data = JSON.parse(text);
  token = data.accessToken;
  tokenExpiresAt = Date.now() + (data.ttlInMinutes ?? 720) * 60_000 - 10 * 60_000;
  return token;
}

const QUERY =
  'query g($category_url: String, $composition: String, $page_id: Int, $size: Int) { ' +
  'getAplCategoryProducts(category_url: $category_url, composition: $composition, page_id: $page_id, size: $size) ' +
  '{ count products category_id } }';

async function fetchPage(variables, page) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const auth = await ensureToken(attempt > 0);
    const { status, text } = await httpGet('https://api.apollo247.com/', limiter, {
      method: 'POST',
      timeoutMs: 45_000,
      headers: { ...BASE_HEADERS, 'content-type': 'application/json', authorization: auth },
      body: JSON.stringify({
        operationName: 'g',
        variables: { ...variables, page_id: page, size: PAGE_SIZE },
        query: QUERY
      })
    });
    if (status === 401 || status === 403) continue; // token rejected: fetch a fresh one and retry once
    if (status >= 400) throw new Error(`HTTP ${status}`);
    const json = JSON.parse(text);
    if (json.errors?.length && !json.data?.getAplCategoryProducts) {
      throw new Error(`GraphQL error: ${JSON.stringify(json.errors[0]).slice(0, 160)}`);
    }
    return json.data?.getAplCategoryProducts ?? { count: 0, products: [] };
  }
  throw new Error('unauthorized after token refresh');
}

/* ───────────── which queries to run ───────────── */

async function categorySlugs() {
  const { text } = await httpGet(
    'https://www.apollopharmacy.in/sitemap/sitemap-pharmacy-category-a-1.xml',
    limiter,
    { maxBytes: 5_000_000 }
  );
  return [...text.matchAll(/shop-by-category\/([^<\s]+)/g)].map((m) => m[1]);
}

async function readCompositions(file) {
  const names = new Set();
  if (!existsSync(file)) return names;
  const rl = createInterface({ input: createReadStream(file, 'utf8'), crlfDelay: Infinity });
  for await (const line of rl) {
    if (!line.trim()) continue;
    try {
      for (const n of saltNames(JSON.parse(line).composition)) names.add(n);
    } catch {
      /* skip torn line */
    }
  }
  return names;
}

async function catalogSalts() {
  const names = new Set();
  if (!process.env.DATABASE_URL) return names;
  const url = new URL(process.env.DATABASE_URL);
  const schema = process.env.DATABASE_SCHEMA || url.searchParams.get('schema') || 'public';
  const client = new pg.Client({
    host: url.hostname,
    port: Number(url.port),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: url.pathname.replace(/^\//, ''),
    ssl: { rejectUnauthorized: false }
  });
  await client.connect();
  const { rows } = await client.query(
    `SELECT lower(trim(m->>'name')) AS salt, count(*) AS n
       FROM "${schema.replace(/"/g, '""')}"."Medicine",
            jsonb_array_elements(CASE WHEN jsonb_typeof("molecules"::jsonb) = 'array' THEN "molecules"::jsonb ELSE '[]'::jsonb END) m
      GROUP BY 1 HAVING count(*) >= $1`,
    [SALT_MIN_COUNT]
  );
  await client.end();
  // Same cleaning as the mapper (salt-form words dropped) so the queries match how compositions are compared.
  for (const { salt } of rows) for (const n of saltNames(salt)) names.add(n);
  return names;
}

async function buildSalts() {
  if (process.env.SALTS_FILE) {
    return readFileSync(process.env.SALTS_FILE, 'utf8').split('\n').map((s) => s.trim().toLowerCase()).filter(Boolean);
  }
  const all = new Set();
  for (const file of ['1mg.jsonl', 'netmeds.jsonl']) {
    for (const n of await readCompositions(join(INDEX_DIR, file))) all.add(n);
  }
  for (const n of await catalogSalts()) all.add(n);
  return [...all].filter((n) => /^[a-z][a-z -]{2,49}$/.test(n)).sort();
}

/* ───────────── crawl ───────────── */

const progress = existsSync(PROGRESS_FILE) ? JSON.parse(readFileSync(PROGRESS_FILE, 'utf8')) : {};
const saveProgress = () => writeFileSync(PROGRESS_FILE, JSON.stringify(progress));

async function runQuery(key, variables, stats) {
  if (progress[key]) return;
  let count = 0;
  let items = 0;
  for (let page = 1; ; page++) {
    const data = await fetchPage(variables, page);
    count = data.count ?? 0;
    const products = data.products ?? [];
    if (products.length) {
      appendFileSync(
        RAW_FILE,
        products
          .map((p) =>
            JSON.stringify({
              sku: p.sku,
              name: p.name,
              slug: p.url_key,
              brand: p.product_brand,
              rx: p.is_prescription_required,
              c: [p.classifier_1, p.classifier_2, p.classifier_3],
              query: key
            })
          )
          .join('\n') + '\n'
      );
    }
    items += products.length;
    stats.pages++;
    if (!products.length || page * PAGE_SIZE >= count) break;
  }
  progress[key] = { count, items };
  saveProgress();
  stats.items += items;
}

/* ───────────── merge raw -> apollo.jsonl ───────────── */

async function merge() {
  if (!existsSync(RAW_FILE)) throw new Error(`nothing to merge: ${RAW_FILE} is missing`);
  const bySku = new Map();
  const rl = createInterface({ input: createReadStream(RAW_FILE, 'utf8'), crlfDelay: Infinity });
  for await (const line of rl) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch {
      continue;
    }
    let entry = bySku.get(row.sku);
    if (!entry) {
      entry = { ...row, salts: new Set(), fromSalt: false };
      bySku.set(row.sku, entry);
    }
    if (row.query.startsWith('salt:')) {
      entry.salts.add(row.query.slice(5));
      entry.fromSalt = true;
    }
  }
  const lines = [];
  for (const e of bySku.values()) {
    // classifier_2 and _3 are often identical; keep the trail free of consecutive repeats.
    const path = e.c.map((s) => (typeof s === 'string' ? s.trim() : '')).filter(Boolean).filter((s, i, a) => s !== a[i - 1]);
    if (!path.length) continue; // Apollo has no class for this product, so it cannot help the mapping
    lines.push(
      JSON.stringify({
        name: e.name,
        slug: e.slug,
        manufacturer: e.brand ?? '',
        composition: [...e.salts].join(' + '),
        rx: String(e.rx),
        path,
        kind: e.fromSalt ? 'medicine' : 'otc'
      })
    );
  }
  writeFileSync(OUT_FILE, lines.join('\n') + '\n');
  console.log(`Merged ${bySku.size} unique Apollo products (${lines.length} with a class) into ${OUT_FILE}`);
}

let claim = 0;

async function main() {
  if (!MERGE_ONLY) {
    const slugs = await categorySlugs();
    const salts = await buildSalts();
    console.log(`Apollo crawl: ${SKIP_CATEGORIES ? 0 : slugs.length} category pages + ${salts.length} salt queries`);
    if (!salts.length) console.warn('  (no salts found — crawl 1mg/Netmeds first, or set DATABASE_URL / SALTS_FILE)');

    const queries = [
      ...(SKIP_CATEGORIES ? [] : slugs).map((s) => ({ key: `cat:${s}`, variables: { category_url: s } })),
      ...salts.map((s) => ({ key: `salt:${s}`, variables: { composition: s } }))
    ].slice(0, QUERY_LIMIT);

    const stats = { pages: 0, items: 0, done: 0, failed: [] };
    const queue = queries.filter((q) => !progress[q.key]);
    console.log(`  ${queries.length - queue.length} already done, ${queue.length} to run`);
    const started = Date.now();
    const timer = setInterval(() => {
      process.stdout.write(
        `\r  queries ${stats.done}/${queue.length} | pages ${stats.pages} | products ${stats.items} | ` +
          `${((Date.now() - started) / 60000).toFixed(1)} min   `
      );
    }, 5000);
    await Promise.all(
      Array.from({ length: CONCURRENCY }, async () => {
        for (;;) {
          const idx = claim++; // shared cursor: each worker takes the next unclaimed query
          if (idx >= queue.length) return;
          try {
            await runQuery(queue[idx].key, queue[idx].variables, stats);
            stats.done++;
          } catch (error) {
            stats.failed.push(`${queue[idx].key}: ${error.message}`);
          }
        }
      })
    );
    clearInterval(timer);
    console.log(`\nCrawled ${stats.pages} pages, ${stats.items} product rows`);
    if (stats.failed.length) {
      console.log(`${stats.failed.length} queries failed (re-run to retry them):`);
      stats.failed.slice(0, 10).forEach((f) => console.log('  ' + f));
    }
  }
  await merge();
}

main().catch((error) => {
  console.error('\n' + error.message);
  process.exit(1);
});
