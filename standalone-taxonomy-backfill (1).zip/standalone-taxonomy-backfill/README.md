# Standalone Competitor-Taxonomy Backfill

Finds, for every medicine in our catalog (~744k), the department / category / subcategory that competitor pharmacy sites file it under: **Tata 1mg, Netmeds, Apollo Pharmacy**. A medicine none of them lists is marked **NOT IDENTIFIED**.

Self-contained — no dependency on the main `medivoy-pharmacy.api` repo, no Prisma. Just `pg`, `exceljs` and Node's built-in `fetch`. **Read-only** against Postgres.

## How it works (two steps)

1. **Crawl** each site once → a local index in `./index/<site>.jsonl` (every product the site lists, with the category path it files it under). A few thousand to ~10k requests per site, not 744k.
2. **Map** our medicines against those indexes locally — no network, fast, repeatable.

For each site, each medicine is mapped in this order:

1. **Name match** — our product name matches a product the site lists → that product's exact category path (`Match Type = name`).
2. **Composition match** — the site doesn't list our brand, but lists other products with the same ingredients (strengths, order and salt forms like "hydrochloride" ignored) → the path most of them are filed under (`Match Type = composition`; the score is the share of those products that agree, needs ≥ `MIN_COMPOSITION_CONFIDENCE`, default 0.6).
3. Neither → `not_found` for that site. A medicine that is `not_found` on every site is **NOT IDENTIFIED**.

## Setup

```bash
npm install
cp .env.example .env      # set DATABASE_URL (the scripts only read from it)
```

## Run

```bash
# 1. Crawl the sites into ./index  (all resumable — re-run after any interruption)
node --env-file=.env crawl-1mg.mjs        # ~1 hour
node --env-file=.env crawl-netmeds.mjs    # ~15-30 min
node --env-file=.env crawl-apollo.mjs     # run AFTER the two above (reuses their ingredient names); 1-2 hours

# 2. Map a sample and check the Excel
SAMPLE=2000 node --env-file=.env backfill-competitor-taxonomy.mjs

# 3. Map the whole catalog (resumable)
node --env-file=.env backfill-competitor-taxonomy.mjs

# Re-map everything from scratch (e.g. after re-crawling or changing thresholds)
FRESH=true node --env-file=.env backfill-competitor-taxonomy.mjs

# Rebuild JSON/Excel from the results so far, without mapping anything
EXPORT_ONLY=true node --env-file=.env backfill-competitor-taxonomy.mjs
```

PowerShell: `$env:SAMPLE='2000'; node --env-file=.env backfill-competitor-taxonomy.mjs; Remove-Item Env:SAMPLE`

### If a site answers 403 from your server

Some sites (1mg in particular) block datacenter IP addresses. The crawl only produces files, so **run the crawl on any machine where the site opens normally** (an office/home PC) and copy the resulting `index/` folder to the server. The mapping step never contacts the sites.

No PC available? Set `PROXY_URL=http://user:pass@host:port` in `.env` and run `npm install` (adds the `undici` package) — the crawlers then send their requests through that proxy.

Never run the mapping step *before* a site's index exists: that site is then reported as `unsupported`/`error` for every medicine (it is retried automatically once the index is there — use `FRESH=true` if you already mapped with a stale or partial index).

## Output — `output/competitor-taxonomy/`

| File | What |
|---|---|
| `results.jsonl` | Working file, one line per medicine. This is the resume state. |
| `taxonomy.json` | Final JSON array, one object per medicine with each site's result. |
| `taxonomy.xlsx` | Final Excel: one row per medicine, a column group per site, plus a Summary sheet. |

Per site the sheet has: status, match type, matched name, department, category, subcategory, full path, URL. **Primary Source** columns take the first site (1mg, then Netmeds, then Apollo) that found the medicine.

`Result` column: `identified` (at least one site lists it), `NOT IDENTIFIED` (every site checked said no), `incomplete` (a site errored and nothing else found it — re-run to retry; an error is never recorded as "not identified").

## Sites

| Site | How | Taxonomy depth |
|---|---|---|
| Tata 1mg | `crawl-1mg.mjs` — therapeutic-class tree; includes each drug's composition | 2 levels: department = parent class, category = class (no subcategory) |
| Netmeds | `crawl-netmeds.mjs` — public JSON catalog API, ~179k products | 4 levels: Medicine/Wellness → L1 → L2 → L3. Department = vertical, category = L1, subcategory = L2; L3 is in *Full Path* |
| Apollo | `crawl-apollo.mjs` — public GraphQL `getAplCategoryProducts` with an anonymous token; ~267 category pages + one query per ingredient | 3 levels: `classifier_1 › classifier_2 › classifier_3` |
| PharmEasy | live search only, **off by default** (`SITES=…,pharmeasy`); its breadcrumb is just "Medicines" | 1 level |
| Truemeds | not usable — product pages carry no category | — |
| MedPlus | not usable — Akamai returns 403 to non-browser clients | — |

Adding a site = a `crawl-<site>.mjs` that writes `index/<site>.jsonl` (rows `{ name, slug, manufacturer, composition, path: [level1, level2, …] }`) plus an `indexAdapter(...)` entry in `lib/adapters.mjs`.

## Coverage expectations

* Real medicines (tablets, syrups, injections…) map well: name match, or composition match on the same ingredients.
* Non-drug products (personal care, devices, homeopathy, food) map only where a site also sells the same product; many will be NOT IDENTIFIED.
* Apollo returns no composition field; a product's composition is rebuilt from the ingredients it was listed under (a Paracetamol + Caffeine tablet appears under both).
* Apollo product links for category-only items are approximate (`/otc/…`).

## Tuning (env vars, see `.env.example`)

`SITES`, `SAMPLE`, `BACKFILL_LIMIT`, `CONCURRENCY`, `NAME_MATCH_THRESHOLD` (default 0.7 — lower = more matches, more mistakes), `MIN_COMPOSITION_CONFIDENCE`, `MIN_COMPOSITION_SUPPORT`, `RPS_<SITE>` (crawl speed), `SALT_MIN_COUNT`, `SALTS_FILE`, `INDEX_DIR`, `OUT_DIR`, `LIVE_FALLBACK`, `FRESH`, `EXPORT_ONLY`.

Scraping may be against these sites' terms of use — keep the crawl rates polite and use the data internally.
